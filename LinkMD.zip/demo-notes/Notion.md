# Notion

An online tool that inspired local-first apps like LinkMD.

See [[Project Ideas]] for why offline-first wiki tools matter.

## Why offline wins

- No internet required
- Files are plain `.md` on your disk
- Full control over your data
