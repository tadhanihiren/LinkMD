# Graph View

The **Graph View** (button in toolbar) shows all your notes as connected nodes.

- Each **node** = a note
- Each **line** = a [[wikilinks]] connection
- **Brighter color** = more links to/from that note
- Click a node to jump to that note
- Drag to pan, scroll to zoom

## In this demo

Open the graph after creating a few notes via [[wikilinks]]. You'll see the connections grow as you link more notes together.

Back to [[How Linking Works]] or [[Welcome to LinkMD]].
