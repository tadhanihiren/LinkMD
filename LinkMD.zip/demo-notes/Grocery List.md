# Grocery List

Created via [[wikilinks]] from [[Recipes]].

- [ ] Pasta
- [ ] Tomato sauce
- [ ] Salad greens
- [ ] Dressing

See [[Project Ideas]] for the full context.
