# How Linking Works

LinkMD uses [[wikilinks]] to connect notes — it's the simplest linking system possible.

## Syntax

Just write `[[Note Title]]` anywhere in your markdown. The title must **exactly match** the target note's title (case-sensitive).

## What happens

1. You type `[[Recipes]]` in the editor
2. Autosave fires → preview re-renders
3. In the preview, `[[Recipes]]` becomes a **clickable purple pill button**
4. Click it → looks for a note titled "Recipes"
   - Found → opens it
   - Not found → creates it automatically

## Backlinks

Open [[Welcome to LinkMD]] and look at the bottom of the preview — you'll see this note listed as a backlink. That's because this note links to [[Welcome to LinkMD]].

## Related

- See the [[Graph View]] to visualize all connections
- Try [[Project Ideas]] for more linking practice
