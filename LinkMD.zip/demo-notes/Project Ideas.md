# Project Ideas

A collection of ideas linked to each other for testing.

## Idea 1: Recipe Manager
- [[Recipes]] for weekly meal planning
- Link ingredients to [[Grocery List]]
- Tag system: #cooking #planning

## Idea 2: Personal Wiki
- Replace [[Notion]] with offline files
- Use [[wikilinks]] for cross-referencing
- Store everything in [[Markdown Formatting]]

## Idea 3: Learning Tracker
- Track courses in [[Courses List]]
- Link concepts with [[wikilinks]]
- Review via [[Graph View]]

---

Linked from: [[Welcome to LinkMD]]
