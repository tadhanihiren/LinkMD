# Courses List

A placeholder note created from [[Project Ideas]].

## Active Courses
- LinkMD — in progress
- The rest is TBD

---

Linked from: [[Project Ideas]]
