# Welcome to LinkMD

This is a demo project to test how [[wikilinks]] work.

## Quick start

1. Create a new note with the **sidebar button** or `Ctrl+N`
2. Type `[[Some Title]]` in the editor to create a link
3. **Save** (autosaves after 500ms) then look at the preview panel
4. **Click the link** — it will create or open that note

## Links to try

- See [[How Linking Works]] for the details
- Check out [[Project Ideas]] for inspiration
- Read about [[Markdown Formatting]] for styling tips

---

Have fun linking!
