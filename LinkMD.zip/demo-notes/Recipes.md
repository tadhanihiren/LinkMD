# Recipes

A note created via [[wikilinks]] from [[Project Ideas]].

## Pasta
- Boil water
- Cook pasta
- Add sauce

## Salad
- Chop vegetables
- Mix dressing
- Toss together

See [[Grocery List]] for shopping.
