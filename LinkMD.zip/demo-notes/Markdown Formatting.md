# Markdown Formatting

This note demonstrates markdown features that work alongside [[wikilinks]].

## Text styles

- **Bold** and *italic* work as expected
- `inline code` for technical terms
- ~~strikethrough~~ for crossed-out items

## Lists

1. Numbered items work
2. Just like in regular markdown

- Bullet points
- Nested lists
  - Like this

## Code blocks

```javascript
// Links are just text in the editor
const title = "My Note";
// [[My Note]] becomes clickable in preview
```

## Blockquotes

> Links make your notes **interconnected**.
> — [[Welcome to LinkMD]]

## Tags

Use #tags for filtering: #linking #markdown #demo

---

Back to [[Welcome to LinkMD]] or see [[How Linking Works]].
