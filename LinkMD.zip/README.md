# LinkMD

A single-file, browser-based markdown note-taking app inspired by Obsidian. Write notes in markdown, link them with `[[wikilinks]]`, organize with `#tags`, and visualize connections in a graph — all in one HTML file, **fully offline**, no server required.

Open the file from `file://` in Chrome/Edge and start writing.

---

## ✨ Features

### Core Editor
- **Markdown editing** with [CodeMirror 6](https://codemirror.net/) — line numbers, syntax highlighting, active line highlight
- **Live preview** via [marked.js](https://marked.js.org/) — renders markdown to HTML as you type
- **Split/Editor/Preview** view modes — cycle through with the toolbar button
- **Ctrl+B** bold, **Ctrl+I** italic — wraps selection in `**` or `*`
- **Scroll sync** between editor and preview panels

### Note Management
- **Create, delete, rename** notes from the sidebar (inline rename on double-click)
- **Search/filter** notes by title in real-time
- **Full-text search** across all notes (Ctrl+K) with fuzzy matching and keyboard navigation
- **Export** individual notes as `.md` files (Ctrl+Shift+E)

### Wiki-Style Linking
- **[[Wikilinks]]** — type `[[Note Title]]` to link notes
- Click a wikilink in the preview to navigate; **creates the note if it doesn't exist**
- **Backlinks panel** below the preview shows all notes linking to the current one

### Organization
- **#tags** — add `#tag` anywhere in your content; click tags in the sidebar to filter notes
- **Tag filter** with one-click clear

### Graph View
- **Interactive graph** of all notes and their `[[wikilinks]]` connections
- Powered by [D3.js v7](https://d3js.org/) force-directed simulation
- Node size/color varies by link count
- Click a node to open that note; drag nodes to reposition; zoom/pan to explore

---

## 🔗 How Linking Works

Linking in LinkMD is **title-based** — no databases, no IDs, just the note's title as text.

### Syntax
```
[[Exact Note Title]]
```
Type this anywhere in your note's markdown content.

### What happens step by step

1. **You type** `[[Recipes]]` in the editor
2. **Autosave fires** (500ms after you stop typing) → the preview panel re-renders
3. **marked.js** converts your markdown to HTML, then a regex replaces every `[[...]]` with a `<a class="wikilink">` element
4. **In the preview**, `[[Recipes]]` appears as a clickable purple pill button
5. **You click it** — JavaScript searches `state.notes` for a note whose `.title` exactly matches `"Recipes"`
   - **Found** → calls `switchToNote(id)` — loads that note into editor and preview
   - **Not found** → calls `createNoteInStorage(id, "Recipes", "")` — creates a new blank note, then switches to it
6. **The new note** is instantly saved to disk (in project mode) or localStorage, and added to `state.notes`

### Important rules

| Rule | Why |
|------|-----|
| **Title must match exactly** | Links are matched by `note.title === linkedTitle`. "Recipes" ≠ "recipes" ≠ "Recipe" |
| **Renaming breaks links** | If you rename a note, old `[[Old Title]]` links in other notes won't auto-update (they're just text) |
| **Circular links are fine** | A → B → C → A works. The graph handles cycles naturally |
| **Spaces in titles** | `[[My Great Note]]` works. There's no special character escaping |
| **Links are plain text in editor** | Wikilinks are only clickable in the **preview panel**. The CodeMirror editor treats them as literal text |

### Backlinks
The **backlinks panel** (bottom of the preview) automatically finds all notes that contain `[[CurrentNoteTitle]]`. It scans every note's content with a regex. No indexing — runs in O(n) per note switch, fast for hundreds of notes.

### Graph
The **Graph View** builds nodes and edges by scanning all `[[wikilinks]]` in all notes. Each unique title becomes a node, each link becomes an edge. The D3.js force simulation lays them out. Brighter color = more connections.

---

## 🧠 How This Project Works

### Architecture Overview

LinkMD is a **single-page application (SPA)** in one HTML file. Everything — HTML, CSS, JavaScript, and bundled libraries — lives in that one file. It uses a **simple state-object pattern** with no framework, no build step, and no server.

```
LinkMD.html
├── <style>          ~1200 lines of CSS (themes, layout, components, modals)
├── <body>           ~80 lines of HTML (toolbar, sidebar, editor, preview, modals)
└── <script>         ~1400 lines of JavaScript (state, storage, UI, editor, graph, search)
```

Libraries in `lib/` are loaded via plain `<script>` tags (works from `file://`):
- `cm-bundle.js` → CodeMirror 6 editor (bundled as IIFE)
- `marked.min.js` → markdown-to-HTML conversion  
- `purify.min.js` → XSS sanitization for preview HTML
- `d3.min.js` → graph visualization

### Startup Flow

```
1. HTML loads → 4 <script> tags load libs (cm, marked, purify, d3)
2. init() called:
   a. Load saved theme from localStorage → apply to <html data-theme="">
   b. initEditor() → create CodeMirror 6 EditorView inside #editorContainer
   c. setViewMode('split') → set initial 3-column grid
   d. initSidebarResize() → wire drag-to-resize on sidebar
   e. Try loading notes from localStorage → if found, show them (returning user)
   f. Otherwise → show welcome screen (Open Folder / Built-in Storage)
3. Event handlers wired to all buttons, keyboard shortcuts registered
4. If focus mode or sidebar collapse was saved → restore them
```

### Data Flow

```
User types in editor
  ↓
CodeMirror updateListener fires (on every keystroke)
  ↓
500ms debounce timer
  ↓
saveCurrentNote()     renderPreview()     renderSidebar()     updateBacklinks()     updateStatusBar()
  ↓                      ↓                    ↓                    ↓                    ↓
diskStorage or      marked.parse() →     re-render note      scan all notes for     word/char count
localStorage        DOMPurify → innerHTML list with filters   [[CurrentTitle]]       read time
```

### State Object

The entire app state is a single plain object:

```js
const state = {
  notes: [],              // Array of { id, title, content, createdAt, updatedAt, fileName, _fileHandle }
  activeNoteId: null,     // Currently open note's id
  viewMode: 'split',      // 'editor' | 'split' | 'preview'
  theme: 'dark',          // 'dark' | 'light'
  searchQuery: '',        // Sidebar filter text
  tagFilter: null,        // Active tag filter
  sidebarWidth: 260,      // In pixels
  isProjectMode: false,   // File System API vs localStorage
  projectHandle: null,    // FileSystemDirectoryHandle
  projectName: '',        // Display name
  focusMode: false,       // Focus mode on/off
  typewriterMode: false,  // Typewriter mode on/off
};
```

All UI reads from `state`. All mutations update `state` then re-render affected parts. This is the **single source of truth**.

### Storage Layer

Two interchangeable backends behind a common API:

| Operation | `storage` (localStorage) | `diskStorage` (File System API) |
|-----------|-------------------------|--------------------------------|
| `getNotes()` | `JSON.parse(localStorage)` | Scan directory → read each `.md` file |
| `saveNote()` | `localStorage.setItem()` | `getFileHandle()` → `createWritable()` → write |
| `createNote()` | Push to array + save | `getFileHandle()` with unique name → write |
| `deleteNote()` | Filter + save | `removeEntry()` from directory handle |
| `renameNote()` | Update title in array | Create new file → delete old → update meta |
| `exportNote()` | Blob from note.content | Blob from note.content |

Both backends update `state.notes` after every mutation. A dispatcher function `saveCurrentNote()` routes to the active backend.

### Autosave

Every keystroke triggers a 500ms debounced save. The autosave indicator shows "Saving..." → "Saved ✓" → clears after 2 seconds. Saving also re-renders the preview, sidebar, backlinks, and status bar.

### Mode Switching (View, Focus, Typewriter)

All mode changes work by **toggling CSS classes** on container elements:

- **View mode**: `.view-editor` / `.view-preview` on `#appLayout` — CSS Grid changes column sizes (`1fr 1fr` split, `1fr 0fr` editor-only, `0fr 1fr` preview-only)
- **Focus mode**: `.focus-mode` on `<body>` — CSS hides toolbar/statusbar, collapses sidebar, dims preview, adds vignette
- **Typewriter mode**: `.typewriter-mode` on `#editorContainer` — CSS adds vertical padding to center cursor, highlights active line

All three are independent — you can be in preview + focus + typewriter simultaneously.

### Graph View

On open, `buildGraph()` scans all notes with a regex for `[[...]]` patterns. It builds a node list (unique titles) and edge list (source → target). D3.js force simulation renders it in an SVG. Clicking a node closes the modal and switches to that note.

### Search

Full-text search (Ctrl+K) does a two-pass scan:
1. **Direct match** — `title.includes(query)` and `content.includes(query)`  
2. **Fuzzy match** — character-by-character subsequence match (allows typos)

Results are scored (title match = 2pts, content match = 1pt) and sorted. Arrow keys navigate, Enter opens.

### What makes it work offline

1. **No `type="module"`** — plain `<script>` tags work from `file://`
2. **No importmap** — removed; all code is in the main script or pre-bundled
3. **Local libraries** — all deps in `lib/`, loaded with relative paths
4. **No CDN** — no internet fetch needed
5. **No server** — `file://` protocol is sufficient
6. **System fonts** — no Google Fonts requests

---

### Display & Focus
- **Dark/Light theme** toggle (Ctrl+Shift+D) — preference saved to localStorage
- **Focus Mode** (Ctrl+Shift+Z) — hides toolbar/status bar, collapses sidebar, dims preview, adds vignette overlay for distraction-free writing
- **Typewriter Mode** (Ctrl+Shift+T) — locks cursor to vertical center of the editor; adds accent underline on active line
- Both modes work together for full distraction-free writing; Esc exits focus mode
- **Sidebar toggle** (Ctrl+\)
- **Fullscreen preview** (Ctrl+Shift+F)

### Status Bar
- Word count, character count, and estimated read time

---

## 📂 Storage Options

### Option 1: Project Folder (Recommended)
Open a folder on your computer. Each note becomes a separate `.md` file on disk.

```
your-project/
├── My Note.md
├── Another Note.md
└── .LinkMD_notes_meta     ← metadata (timestamps, IDs)
```

- **Open Project Folder** — click the toolbar button or welcome screen
- **Close Project** — unloads the folder and returns to the welcome screen
- All notes are plain `.md` files you can open in any editor
- Works in **Chrome** and **Edge** (requires File System Access API)

### Option 2: Built-in Storage (Fallback)
Notes are saved in your browser's `localStorage`. No setup needed, works in any browser, but notes stay in that browser only.

---

## 🔌 Tech Stack — Fully Offline

All libraries are bundled locally in `lib/` — **no CDN, no internet, no server needed**.

| File | Purpose |
|------|---------|
| `lib/cm-bundle.js` | CodeMirror 6 editor (IIFE bundle, 985KB) |
| `lib/marked.min.js` | Markdown → HTML rendering |
| `lib/purify.min.js` | HTML sanitization (XSS prevention) |
| `lib/d3.min.js` | Graph visualization |

CodeMirror is bundled as a single non-module IIFE from real npm packages (`@codemirror/state`, `@codemirror/view`, `@codemirror/lang-markdown`, etc.) via esbuild — no `importmap` or ES modules needed, so it works from `file://` without CORS issues.

---

## 🚀 Getting Started

### Option A: Open an Existing Project

If you already have a folder of `.md` notes (like the `demo-notes/` folder included with LinkMD):

1. Open `LinkMD.html` in **Chrome** or **Edge** (from `file://` — just double-click the file)
2. You'll see a **welcome screen** with two buttons
3. Click **"Open Project Folder"** — a folder picker dialog opens
4. Navigate to your notes folder (e.g. `F:\linkmd\demo-notes\`) and click **Select Folder**
5. All `.md` files in that folder load into the sidebar as notes
6. Click any note to open it

The folder's structure stays unchanged — your `.md` files are read/written directly. LinkMD adds a `.LinkMD_notes_meta` file to store metadata (titles, timestamps, IDs).

### Option B: Create a New Project from Scratch

1. Open `LinkMD.html` → welcome screen appears
2. Click **"Open Project Folder"** 
3. **Create a new empty folder** using the folder picker dialog (click "Make New Folder" in the dialog)
4. Name it (e.g. `my-notes`) and click **Select Folder**
5. LinkMD loads the empty folder — **no notes yet**
6. Click **"+ New Note"** in the sidebar (or press `Ctrl+N`) to create your first note
7. Start typing — your note is saved as a `.md` file in the folder automatically

Now you have a real project on disk. You can open those `.md` files in any other editor anytime.

### Option C: Try Without a Folder (Built-in Storage)

No project folder? No problem:

1. Open `LinkMD.html` → welcome screen
2. Click **"Use Built-in Storage"**
3. A welcome note appears automatically
4. Create notes and write freely — everything is saved in your browser's `localStorage`

> ⚠ Notes stay in that browser only. Clearing browser data will delete them. Use **Project Folder** mode for real work.

### Switching Projects

To switch to a different project:

1. Click **"Close"** in the toolbar (next to the project name badge)
2. The welcome screen reappears
3. Click **"Open Project Folder"** again and pick a different folder

You can have only one project open at a time. Close the current one before opening another.

### Demo Notes

A sample project with interconnected notes is included at `demo-notes/`:

```
F:\linkmd\demo-notes\
├── Welcome to LinkMD.md       ← start here
├── How Linking Works.md
├── Project Ideas.md
├── Markdown Formatting.md
├── Recipes.md
├── Grocery List.md
├── Graph View.md
├── Notion.md
├── Courses List.md
└── .LinkMD_notes_meta
```

Open it via **Open Project Folder** to test wikilinks, backlinks, and graph view immediately.

---

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Ctrl+B | Bold |
| Ctrl+I | Italic |
| Ctrl+K | Search notes |
| Ctrl+N | New note |
| Ctrl+\ | Toggle sidebar |
| Ctrl+Shift+D | Toggle theme |
| Ctrl+Shift+Z | Focus mode |
| Ctrl+Shift+T | Typewriter mode |
| Ctrl+Shift+F | Fullscreen preview |
| Ctrl+Shift+E | Export note |
| ? | Show shortcuts |
| Escape | Close modal / exit fullscreen / exit focus |

---

## 🖥️ Browser Support

| Browser | Project Mode | Built-in Mode |
|---------|-------------|---------------|
| Chrome / Edge | ✅ Full support | ✅ |
| Firefox | ❌ Not supported | ✅ |
| Safari | ❌ Not supported | ✅ |
| Opera | ✅ Full support | ✅ |

Project mode uses the [File System Access API](https://developer.mozilla.org/en-US/docs/Web/API/File_System_Access_API), which is currently supported by Chromium-based browsers only.

---

## ⚠️ Known Issues & Changelog

### Fixed Bugs
- **Data loss with untitled notes** — Multiple "Untitled" notes no longer all overwrite `Untitled.md`. Each new note gets a unique `_id` suffix in its filename.
- **Export broken in project mode** — Export now creates Blobs directly from in-memory state instead of delegating to localStorage.
- **Data race on wikilink create** — Creating notes via `[[wikilinks]]` no longer re-reads all files from disk (which could lose unsaved autosave-pending changes).
- **Mobile blank area** — Preview panel now shows correctly in preview mode on narrow screens.
- **View toggle (preview mode broken)** — CSS Grid `display:none` removed the hidden panel from the grid, misaligning columns. Fixed by letting `0fr` column width handle visibility instead.

---

## 📄 License

MIT — do whatever you want with it.
